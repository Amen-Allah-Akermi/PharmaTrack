<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Récupération des régions
    $stmt = $pdo->query("SELECT id, nom FROM regions ORDER BY nom");
    $regions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'regions' => $regions
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erreur lors de la récupération des régions: ' . $e->getMessage()
    ]);
}
?>