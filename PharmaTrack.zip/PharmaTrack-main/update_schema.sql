-- Ajout des champs manquants à la table pharmacies
ALTER TABLE pharmacies
ADD COLUMN tentatives_echec INT DEFAULT 0,
ADD COLUMN compte_bloque BOOLEAN DEFAULT FALSE; 