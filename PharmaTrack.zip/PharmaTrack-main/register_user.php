<?php
require_once 'config.php';
require_once 'functions.php';

// Activer l'affichage des erreurs pour le débogage
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Récupérer les données JSON
$data = json_decode(file_get_contents("php://input"), true);

// Vérifier si les données sont valides
if (!$data) {
    echo json_encode(['error' => 'Données invalides']);
    exit;
}

// Nettoyer les données
$nom = clean_input($data['nom']);
$prenom = clean_input($data['prenom']);
$region = clean_input($data['region']);
$latitude = clean_input($data['latitude']);
$longitude = clean_input($data['longitude']);

// Vérifier si tous les champs requis sont présents
if (empty($nom) || empty($prenom) || empty($region) || empty($latitude) || empty($longitude)) {
    echo json_encode(['error' => 'Tous les champs sont obligatoires']);
    exit;
}

// Obtenir l'ID de la région
$regionId = getRegionId($region);
if (!$regionId) {
    echo json_encode(['error' => 'Région invalide: ' . $region]);
    exit;
}

try {
    // Préparer la requête SQL
    $date_creation = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, region_id, latitude, longitude, date_creation) VALUES (?, ?, ?, ?, ?, ?)");
    
    // Exécuter la requête SQL
    $stmt->execute([$nom, $prenom, $regionId, $latitude, $longitude, $date_creation]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Erreur lors de l\'enregistrement de l\'utilisateur: ' . $e->getMessage()]);
}
?>