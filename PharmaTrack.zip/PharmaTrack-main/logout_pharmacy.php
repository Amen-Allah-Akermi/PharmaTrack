<?php
header('Content-Type: application/json');
session_start();

// Vérification si l'utilisateur est connecté
if (!isset($_SESSION['pharmacy_id'])) {
    echo json_encode(['success' => false, 'message' => 'Vous n\'êtes pas connecté']);
    exit;
}

// Destruction de la session
session_destroy();

// Suppression du cookie de session si présent
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

echo json_encode(['success' => true, 'message' => 'Déconnexion réussie']);
?> 