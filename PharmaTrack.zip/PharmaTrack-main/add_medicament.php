<?php
require_once 'config.php';
require_once 'functions.php';

// Vérifier si l'utilisateur est connecté
session_start();
if (!isset($_SESSION['pharmacy_id'])) {
    echo json_encode(['error' => 'Non autorisé. Veuillez vous connecter.']);
    exit;
}

// Récupérer et valider les données
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['nom']) || !isset($data['code_pct']) || !isset($data['quantite']) || !isset($data['prix'])) {
    echo json_encode(['error' => 'Données manquantes']);
    exit;
}

$nom = clean_input($data['nom']);
$code_pct = clean_input($data['code_pct']);
$quantite = clean_input($data['quantite']);
$prix = clean_input($data['prix']);

// Validation des données
if (empty($nom) || empty($code_pct) || !is_numeric($quantite) || !is_numeric($prix)) {
    echo json_encode(['error' => 'Données invalides']);
    exit;
}

if (!preg_match('/^\d{6}$/', $code_pct)) {
    echo json_encode(['error' => 'Le code PCT doit contenir exactement 6 chiffres']);
    exit;
}

if ($quantite < 0 || $prix < 0) {
    echo json_encode(['error' => 'La quantité et le prix doivent être positifs']);
    exit;
}

try {
    if (updateMedicamentStock($_SESSION['pharmacy_id'], $nom, $code_pct, $quantite, $prix)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Erreur lors de l\'ajout du médicament']);
    }
} catch (Exception $e) {
    error_log("Erreur dans add_medicament.php : " . $e->getMessage());
    echo json_encode(['error' => 'Une erreur est survenue lors de l\'ajout du médicament']);
}
?>