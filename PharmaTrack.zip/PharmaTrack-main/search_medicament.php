<?php
header('Content-Type: application/json');

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pharmatrack";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("SET NAMES utf8");
} catch(PDOException $e) {
    echo json_encode(["success" => false, "error" => "Erreur de connexion: " . $e->getMessage()]);
    exit;
}

// Récupérer les paramètres de recherche
$nom = isset($_GET['nom']) ? $_GET['nom'] : '';
$forme = isset($_GET['forme']) ? $_GET['forme'] : '';
$laboratoire = isset($_GET['laboratoire']) ? $_GET['laboratoire'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : 'nom'; // Par défaut, recherche par nom
$region = isset($_GET['region']) ? $_GET['region'] : '';

// Get region_id from regions table
$stmt = $conn->prepare("SELECT id FROM regions WHERE nom = :region");
$stmt->execute([':region' => $region]);
$region_id = $stmt->fetchColumn();

// Log pour débogage
error_log("Paramètres reçus:");
error_log("Nom: " . $nom);
error_log("Forme: " . $forme);
error_log("Laboratoire: " . $laboratoire);
error_log("Type: " . $type);
error_log("Région: " . $region);

// Vérifier si la région est fournie
if (empty($region)) {
    echo json_encode(["success" => false, "error" => "Veuillez sélectionner une région"]);
    exit;
}

// Vérifier si au moins un critère de recherche est fourni
if (empty($nom) && empty($forme) && empty($laboratoire)) {
    echo json_encode(["success" => false, "error" => "Veuillez fournir au moins un critère de recherche"]);
    exit;
}

try {
    // Build the query
    $sql = "SELECT DISTINCT p.id as pharmacie_id, p.nom as pharmacie_nom, p.telephone, p.latitude, p.longitude, 
            p.type_pharmacie, p.heure_ouverture, p.heure_fermeture, p.jour_repos,
            m.id as medicament_id, m.nom as medicament_nom, m.forme, m.laboratoire,
            sp.prix, sp.quantite, sp.code_pct
            FROM pharmacies p
            INNER JOIN regions r ON p.region_id = r.id
            LEFT JOIN stocks_pharmacies sp ON p.id = sp.pharmacie_id
            LEFT JOIN medicaments m ON sp.medicament_id = m.id
            WHERE r.nom LIKE :region";

    $params = [':region' => $region];

    if (!empty($nom)) {
        $sql .= " AND m.nom LIKE :nom";
        $params[':nom'] = "%$nom%";
    }

    if (!empty($forme)) {
        $sql .= " AND m.forme LIKE :forme";
        $params[':forme'] = "%$forme%";
    }

    if (!empty($laboratoire)) {
        $sql .= " AND m.laboratoire LIKE :laboratoire";
        $params[':laboratoire'] = "%$laboratoire%";
    }

    $sql .= " ORDER BY p.nom, m.nom LIMIT 20";

    // Log pour débogage
    error_log("Requête SQL finale: " . $sql);
    error_log("Paramètres SQL: " . print_r($params, true));
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Log pour débogage
    error_log("Nombre de résultats: " . count($results));
    
    if (count($results) > 0) {
        // Restructurer les résultats pour correspondre au format attendu
        $pharmacies = [];
        foreach ($results as $result) {
            $pharmacie_nom = $result['pharmacie_nom'];
            
            // Si cette pharmacie n'existe pas encore dans notre tableau
            if (!isset($pharmacies[$pharmacie_nom])) {
                $pharmacies[$pharmacie_nom] = [
                    'pharmacie_nom' => $pharmacie_nom,
                    'type' => $result['type_pharmacie'],
                    'horaires' => [
                        'ouverture' => $result['heure_ouverture'],
                        'fermeture' => $result['heure_fermeture']
                    ],
                    'jour_repos' => $result['jour_repos'],
                    'telephone' => $result['telephone'],
                    'latitude' => $result['latitude'],
                    'longitude' => $result['longitude'],
                    'medicaments' => []
                ];
            }
            
            // Ajouter le médicament à la pharmacie seulement s'il existe
            if ($result['medicament_id'] !== null) {
                $pharmacies[$pharmacie_nom]['medicaments'][] = [
                    'nom' => $result['medicament_nom'],
                    'forme' => $result['forme'],
                    'laboratoire' => $result['laboratoire'],
                    'quantite' => $result['quantite'],
                    'code_pct' => $result['code_pct'],
                    'prix' => $result['prix']
                ];
            }
        }
        
        echo json_encode([
            "success" => true, 
            "pharmacies" => array_values($pharmacies)
        ]);
    } else {
        echo json_encode([
            "success" => false, 
            "error" => "Désolé, nous n'avons pas trouvé ce médicament dans nos pharmacies partenaires. Veuillez vérifier l'orthographe ou essayer un autre nom."
        ]);
    }
} catch(PDOException $e) {
    echo json_encode(["success" => false, "error" => "Erreur de requête: " . $e->getMessage()]);
}

$conn = null;
?> 