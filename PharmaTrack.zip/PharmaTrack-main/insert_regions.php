<?php
require_once 'config.php';

// Activer l'affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Insertion des régions</h1>";

// Liste des régions tunisiennes
$regions = [
    'Ariana', 'Beja', 'Ben Arous', 'Bizerte', 'Gabes',
    'Gafsa', 'Jendouba', 'Kairouan', 'Kasserine', 'Kebili',
    'Kef', 'Mahdia', 'Manouba', 'Medenine', 'Monastir',
    'Nabeul', 'Sfax', 'Sidi Bouzid', 'Siliana', 'Sousse',
    'Tataouine', 'Tozeur', 'Tunis', 'Zaghouan'
];

// Vérifier si la table regions existe
$sql = "SHOW TABLES LIKE 'regions'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // Créer la table regions si elle n'existe pas
    $sql = "CREATE TABLE regions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        nom VARCHAR(50) NOT NULL
    )";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p>Table 'regions' créée avec succès.</p>";
    } else {
        echo "<p>Erreur lors de la création de la table 'regions': " . $conn->error . "</p>";
        exit;
    }
}

// Insérer les régions
$inserted = 0;
$existing = 0;

foreach ($regions as $region) {
    // Vérifier si la région existe déjà
    $sql = "SELECT id FROM regions WHERE nom = '$region'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 0) {
        // Insérer la région
        $sql = "INSERT INTO regions (nom) VALUES ('$region')";
        if ($conn->query($sql) === TRUE) {
            $inserted++;
        } else {
            echo "<p>Erreur lors de l'insertion de la région '$region': " . $conn->error . "</p>";
        }
    } else {
        $existing++;
    }
}

echo "<p>$inserted régions insérées avec succès.</p>";
echo "<p>$existing régions existaient déjà.</p>";

// Afficher toutes les régions
$sql = "SELECT id, nom FROM regions ORDER BY nom";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Liste des régions:</h2>";
    echo "<ul>";
    while($row = $result->fetch_assoc()) {
        echo "<li>ID: " . $row['id'] . ", Nom: " . $row['nom'] . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Aucune région trouvée dans la base de données.</p>";
}
?> 