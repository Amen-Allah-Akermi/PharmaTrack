<?php
session_start();
header('Content-Type: application/json');

// Détruire toutes les variables de session
$_SESSION = array();

// Détruire la session
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-3600, '/');
}
session_destroy();

// Renvoyer une réponse de succès
echo json_encode(['success' => true]);
?> 