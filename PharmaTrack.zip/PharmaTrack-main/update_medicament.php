<?php
require_once 'config.php';
require_once 'functions.php';

// Vérifier si l'utilisateur est connecté
session_start();
if (!isset($_SESSION['pharmacy_id'])) {
    echo json_encode(['error' => 'Non autorisé. Veuillez vous connecter.']);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['nom'])) {
    echo json_encode(['error' => 'Données manquantes']);
    exit;
}

$nom = clean_input($data['nom']);
$codePct = isset($data['code_pct']) ? clean_input($data['code_pct']) : null;
$quantite = isset($data['quantite']) ? clean_input($data['quantite']) : null;
$prix = isset($data['prix']) ? clean_input($data['prix']) : null;

// Validation des données
if (empty($nom)) {
    echo json_encode(['error' => 'Nom de médicament invalide']);
    exit;
}

// Validation du code PCT si fourni
if ($codePct !== null) {
    if (!preg_match('/^\d{6}$/', $codePct)) {
        echo json_encode(['error' => 'Le code PCT doit contenir exactement 6 chiffres']);
        exit;
    }
}

// Validation de la quantité si fournie
if ($quantite !== null) {
    if (!is_numeric($quantite) || $quantite < 0) {
        echo json_encode(['error' => 'La quantité doit être un nombre positif']);
        exit;
    }
}

// Validation du prix si fourni
if ($prix !== null) {
    if (!is_numeric($prix) || $prix < 0) {
        echo json_encode(['error' => 'Le prix doit être un nombre positif']);
        exit;
    }
}

try {
    // Récupérer les valeurs actuelles du médicament
    $stmt = $pdo->prepare("
        SELECT sp.code_pct, sp.quantite, sp.prix 
        FROM stocks_pharmacies sp
        JOIN medicaments m ON sp.medicament_id = m.id
        WHERE m.nom = ? AND sp.pharmacie_id = ?
    ");
    $stmt->execute([$nom, $_SESSION['pharmacy_id']]);
    $currentValues = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentValues) {
        echo json_encode(['error' => 'Médicament non trouvé']);
        exit;
    }

    // Utiliser les nouvelles valeurs ou les valeurs actuelles
    $newCodePct = $codePct !== null ? $codePct : $currentValues['code_pct'];
    $newQuantite = $quantite !== null ? $quantite : $currentValues['quantite'];
    $newPrix = $prix !== null ? $prix : $currentValues['prix'];

    // Mettre à jour le stock
    $stmt = $pdo->prepare("
        UPDATE stocks_pharmacies sp
        JOIN medicaments m ON sp.medicament_id = m.id
        SET sp.code_pct = ?,
            sp.quantite = ?,
            sp.prix = ?
        WHERE m.nom = ? AND sp.pharmacie_id = ?
    ");
    
    if ($stmt->execute([$newCodePct, $newQuantite, $newPrix, $nom, $_SESSION['pharmacy_id']])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Erreur lors de la mise à jour du médicament']);
    }
} catch (Exception $e) {
    error_log("Erreur dans update_medicament.php : " . $e->getMessage());
    echo json_encode(['error' => 'Une erreur est survenue lors de la mise à jour du médicament']);
}
?>