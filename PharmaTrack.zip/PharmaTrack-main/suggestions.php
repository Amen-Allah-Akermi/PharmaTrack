<?php
header('Content-Type: application/json');

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pharmatrack";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("SET NAMES utf8");
} catch(PDOException $e) {
    echo json_encode(["error" => "Erreur de connexion: " . $e->getMessage()]);
    exit;
}

// Récupérer le terme de recherche et le type
$search = isset($_GET['search']) ? $_GET['search'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : 'nom';

try {
    // Préparer la requête en fonction du type de recherche
    $sql = "";
    $stmt = null;
    
    switch ($type) {
        case 'nom':
            if (empty($search)) {
                echo json_encode([]);
                exit;
            }
            $sql = "SELECT DISTINCT nom FROM medicaments WHERE nom LIKE :search ORDER BY nom LIMIT 10";
            $stmt = $conn->prepare($sql);
            $stmt->execute(['search' => "%$search%"]);
            break;
            
        case 'forme':
            $sql = "SELECT DISTINCT forme FROM medicaments WHERE forme IS NOT NULL AND forme != '' ORDER BY forme";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            break;
            
        case 'laboratoire':
            $sql = "SELECT DISTINCT laboratoire FROM medicaments WHERE laboratoire IS NOT NULL AND laboratoire != '' ORDER BY laboratoire";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            break;
            
        default:
            throw new Exception("Type de recherche invalide");
    }
    
    $results = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode($results);

} catch(PDOException $e) {
    echo json_encode(["error" => "Erreur de requête: " . $e->getMessage()]);
} catch(Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

$conn = null;
?> 