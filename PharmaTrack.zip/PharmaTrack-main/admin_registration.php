<?php

$nom = $_POST['nom'];
$email = $_POST['email'];
$mot_de_passe = password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT);
$telephone = $_POST['telephone'];
$region_id = $_POST['region_id'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$jour_repos = $_POST['jour_repos'];
$heure_ouverture = $_POST['heure_ouverture'];
$heure_fermeture = $_POST['heure_fermeture'];
$type_pharmacie = $_POST['type_pharmacie'];

$sql = "INSERT INTO pharmacies (nom, email, mot_de_passe, telephone, region_id, latitude, longitude, jour_repos, heure_ouverture, heure_fermeture, type_pharmacie) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssiiddsss", $nom, $email, $mot_de_passe, $telephone, $region_id, $latitude, $longitude, $jour_repos, $heure_ouverture, $heure_fermeture, $type_pharmacie);

// ... existing code ... 