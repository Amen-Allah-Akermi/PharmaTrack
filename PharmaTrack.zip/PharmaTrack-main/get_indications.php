<?php
header('Content-Type: application/json');

// Vérifier si les paramètres requis sont présents
if (!isset($_GET['nom'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Paramètre nom manquant'
    ]);
    exit;
}

$nom = $_GET['nom'];

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=pharmatrack', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Requête pour récupérer les indications
    $stmt = $pdo->prepare("
        SELECT indications 
        FROM medicaments 
        WHERE nom = :nom
    ");
    
    $stmt->execute([
        ':nom' => $nom
    ]);

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo json_encode([
            'success' => true,
            'indications' => $result['indications']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Aucune indication trouvée pour ce médicament'
        ]);
    }

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Erreur de base de données: ' . $e->getMessage()
    ]);
}
?> 