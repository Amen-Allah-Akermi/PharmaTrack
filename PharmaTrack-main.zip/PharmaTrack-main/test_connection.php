<?php
require_once 'config.php';

echo "<h1>Test de connexion à la base de données</h1>";

if ($conn->connect_error) {
    die("Erreur de connexion à la base de données: " . $conn->connect_error);
} else {
    echo "<p>Connexion à la base de données réussie!</p>";
}

// Vérifier si la table regions existe
$sql = "SHOW TABLES LIKE 'regions'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<p>La table 'regions' existe.</p>";
    
    // Vérifier le contenu de la table regions
    $sql = "SELECT * FROM regions";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "<p>La table 'regions' contient " . $result->num_rows . " enregistrements.</p>";
        echo "<h2>Contenu de la table 'regions':</h2>";
        echo "<ul>";
        while($row = $result->fetch_assoc()) {
            echo "<li>ID: " . $row['id'] . ", Nom: " . $row['nom'] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>La table 'regions' est vide.</p>";
    }
} else {
    echo "<p>La table 'regions' n'existe pas.</p>";
}

// Vérifier si la table utilisateurs existe
$sql = "SHOW TABLES LIKE 'utilisateurs'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<p>La table 'utilisateurs' existe.</p>";
    
    // Afficher la structure de la table utilisateurs
    $sql = "DESCRIBE utilisateurs";
    $result = $conn->query($sql);
    
    echo "<h2>Structure de la table 'utilisateurs':</h2>";
    echo "<ul>";
    while($row = $result->fetch_assoc()) {
        echo "<li>Champ: " . $row['Field'] . ", Type: " . $row['Type'] . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>La table 'utilisateurs' n'existe pas.</p>";
}
?> 