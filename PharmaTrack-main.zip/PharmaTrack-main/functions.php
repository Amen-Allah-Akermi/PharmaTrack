<?php
require_once 'config.php';

// Fonction pour vérifier si l'email existe déjà
function emailExists($email) {
    global $pdo;
    $email = clean_input($email);
    $stmt = $pdo->prepare("SELECT id FROM pharmacies WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->rowCount() > 0;
}

// Fonction pour obtenir l'ID de la région à partir de son nom
function getRegionId($nom) {
    global $pdo;
    $nom = clean_input($nom);
    $stmt = $pdo->prepare("SELECT id FROM regions WHERE nom = ?");
    $stmt->execute([$nom]);
    if ($stmt->rowCount() > 0) {
        return $stmt->fetchColumn();
    }
    return false;
}

// Fonction pour obtenir toutes les régions
function getAllRegions() {
    global $pdo;
    $stmt = $pdo->query("SELECT nom FROM regions ORDER BY nom");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Fonction pour obtenir tous les médicaments
function getAllMedicaments() {
    global $pdo;
    $stmt = $pdo->query("SELECT nom FROM medicaments ORDER BY nom");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Fonction pour rechercher un médicament et trouver les pharmacies qui l'ont en stock
function searchMedicament($nom, $userLat, $userLng, $regionId) {
    global $pdo;
    $nom = clean_input($nom);
    
    // Obtenir l'ID du médicament
    $stmt = $pdo->prepare("SELECT id FROM medicaments WHERE nom LIKE ? LIMIT 1");
    $stmt->execute(["%$nom%"]);
    
    if ($stmt->rowCount() == 0) {
        return array("error" => "Médicament non trouvé.");
    }
    
    $medicamentId = $stmt->fetchColumn();
    
    // Trouver les pharmacies qui ont ce médicament en stock
    $stmt = $pdo->prepare("
        SELECT p.id, p.nom, p.region_id, p.jour_repos, p.latitude, p.longitude, sp.quantite, sp.prix
        FROM pharmacies p
        JOIN stocks_pharmacies sp ON p.id = sp.pharmacie_id
        WHERE sp.medicament_id = ? AND sp.quantite >= 1
        ORDER BY 
            (p.region_id = ?) DESC, 
            (6371 * acos(cos(radians(?)) * cos(radians(p.latitude)) * cos(radians(p.longitude) - radians(?)) + sin(radians(?)) * sin(radians(p.latitude))))
    ");
    
    $stmt->execute([$medicamentId, $regionId, $userLat, $userLng, $userLat]);
    $pharmacies = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $pharmacies[] = array(
            "pharmacie" => $row['nom'],
            "stock" => $row['quantite'],
            "prix" => $row['prix'],
            "jour_repos" => $row['jour_repos'],
            "latitude" => $row['latitude'],
            "longitude" => $row['longitude']
        );
    }
    
    return !empty($pharmacies) ? $pharmacies : array("error" => "Aucune pharmacie n'a ce médicament en stock.");
}

// Fonction pour suggérer des médicaments basés sur un terme de recherche
function suggestMedicaments($term) {
    global $pdo;
    $term = clean_input($term);
    $stmt = $pdo->prepare("SELECT nom FROM medicaments WHERE nom LIKE ? ORDER BY nom LIMIT 10");
    $stmt->execute(["%$term%"]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Fonction pour ajouter ou mettre à jour un stock de médicament
function updateMedicamentStock($pharmacieId, $medicamentNom, $codePct, $quantite, $prix) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Vérifier si le médicament existe, sinon l'ajouter
        $medicamentNom = clean_input($medicamentNom);
        $codePct = clean_input($codePct);
        $stmt = $pdo->prepare("SELECT id FROM medicaments WHERE nom = ?");
        $stmt->execute([$medicamentNom]);
        
        if ($stmt->rowCount() > 0) {
            $medicamentId = $stmt->fetchColumn();
        } else {
            // Ajouter le nouveau médicament
            $stmt = $pdo->prepare("INSERT INTO medicaments (nom) VALUES (?)");
            $stmt->execute([$medicamentNom]);
            $medicamentId = $pdo->lastInsertId();
        }
        
        // Vérifier si un stock existe déjà pour ce médicament dans cette pharmacie
        $stmt = $pdo->prepare("SELECT id FROM stocks_pharmacies WHERE pharmacie_id = ? AND medicament_id = ?");
        $stmt->execute([$pharmacieId, $medicamentId]);
        
        if ($stmt->rowCount() > 0) {
            // Mettre à jour le stock existant
            $stmt = $pdo->prepare("
                UPDATE stocks_pharmacies 
                SET quantite = ?, 
                    prix = ?, 
                    code_pct = ?,
                    date_modification = NOW() 
                WHERE pharmacie_id = ? AND medicament_id = ?
            ");
            $stmt->execute([$quantite, $prix, $codePct, $pharmacieId, $medicamentId]);
        } else {
            // Créer un nouveau stock
            $stmt = $pdo->prepare("
                INSERT INTO stocks_pharmacies (pharmacie_id, medicament_id, quantite, prix, code_pct, date_modification) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$pharmacieId, $medicamentId, $quantite, $prix, $codePct]);
        }
        
        $pdo->commit();
        return true;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erreur dans updateMedicamentStock : " . $e->getMessage());
        return false;
    }
}

// Fonction pour supprimer un médicament du stock d'une pharmacie
function removeMedicamentFromStock($pharmacieId, $medicamentNom) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $medicamentNom = clean_input($medicamentNom);
        
        // Obtenir l'ID du médicament
        $stmt = $pdo->prepare("SELECT id FROM medicaments WHERE nom = ?");
        $stmt->execute([$medicamentNom]);
        
        if ($stmt->rowCount() == 0) {
            return false; // Médicament non trouvé
        }
        
        $medicamentId = $stmt->fetchColumn();
        
        // Supprimer le stock
        $stmt = $pdo->prepare("DELETE FROM stocks_pharmacies WHERE pharmacie_id = ? AND medicament_id = ?");
        $stmt->execute([$pharmacieId, $medicamentId]);
        
        $pdo->commit();
        return true;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erreur dans removeMedicamentFromStock : " . $e->getMessage());
        return false;
    }
}

// Fonction pour obtenir les stocks de médicaments d'une pharmacie
function getPharmacieStock($pharmacieId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT m.nom, sp.quantite, sp.prix, sp.code_pct 
        FROM stocks_pharmacies sp
        JOIN medicaments m ON sp.medicament_id = m.id
        WHERE sp.pharmacie_id = ?
        ORDER BY m.nom
    ");
    
    $stmt->execute([$pharmacieId]);
    $stocks = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $stocks[] = array(
            "nom" => $row['nom'],
            "code_pct" => $row['code_pct'],
            "quantite" => $row['quantite'],
            "prix" => $row['prix']
        );
    }
    
    return $stocks;
}
?>