<?php
require_once 'config.php';
require_once 'functions.php';

// Vérifier si l'utilisateur est connecté
session_start();
if (!isset($_SESSION['pharmacy_id'])) {
    echo json_encode(['error' => 'Non autorisé. Veuillez vous connecter.']);
    exit;
}

try {
    $stocks = getPharmacieStock($_SESSION['pharmacy_id']);
    echo json_encode($stocks);
} catch (Exception $e) {
    error_log("Erreur dans get_stock.php : " . $e->getMessage());
    echo json_encode(['error' => 'Une erreur est survenue lors de la récupération des stocks']);
}
?>