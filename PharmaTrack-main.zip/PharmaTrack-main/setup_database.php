<?php
require_once 'config.php';

// Création de la base de données si elle n'existe pas
$sql = "CREATE DATABASE IF NOT EXISTS pharmatrack";
if ($conn->query($sql) === TRUE) {
    echo "Base de données créée avec succès ou déjà existante<br>";
} else {
    echo "Erreur lors de la création de la base de données : " . $conn->error . "<br>";
}

// Sélection de la base de données
$conn->select_db("pharmatrack");

// Création de la table medicaments
$sql = "CREATE TABLE IF NOT EXISTS medicaments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql) === TRUE) {
    echo "Table medicaments créée avec succès ou déjà existante<br>";
} else {
    echo "Erreur lors de la création de la table medicaments : " . $conn->error . "<br>";
}

// Création de la table pharmacies
$sql = "CREATE TABLE IF NOT EXISTS pharmacies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    adresse TEXT,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql) === TRUE) {
    echo "Table pharmacies créée avec succès ou déjà existante<br>";
} else {
    echo "Erreur lors de la création de la table pharmacies : " . $conn->error . "<br>";
}

// Création de la table stocks_pharmacies
$sql = "CREATE TABLE IF NOT EXISTS stocks_pharmacies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pharmacie_id INT,
    medicament_id INT,
    quantite INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pharmacie_id) REFERENCES pharmacies(id),
    FOREIGN KEY (medicament_id) REFERENCES medicaments(id)
)";
if ($conn->query($sql) === TRUE) {
    echo "Table stocks_pharmacies créée avec succès ou déjà existante<br>";
} else {
    echo "Erreur lors de la création de la table stocks_pharmacies : " . $conn->error . "<br>";
}

// Insertion de quelques données de test
$medicaments = [
    "Paracétamol",
    "Ibuprofène",
    "Amoxicilline",
    "Doliprane",
    "Aspirine",
    "Voltarène",
    "Smecta",
    "Spasfon",
    "Efferalgan",
    "Levothyrox"
];

foreach ($medicaments as $medicament) {
    $stmt = $conn->prepare("INSERT IGNORE INTO medicaments (nom) VALUES (?)");
    $stmt->bind_param("s", $medicament);
    $stmt->execute();
}

echo "Données de test insérées avec succès<br>";

$conn->close();
?> 