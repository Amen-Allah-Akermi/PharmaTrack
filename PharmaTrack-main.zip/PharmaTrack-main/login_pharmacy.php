<?php
header('Content-Type: application/json');
require_once 'config.php';

// Vérification de la méthode de requête
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

// Récupération des données du formulaire
$data = json_decode(file_get_contents('php://input'), true);

// Vérification des champs requis
if (empty($data['email']) || empty($data['password'])) {
    echo json_encode(['success' => false, 'message' => 'Email et mot de passe requis']);
    exit;
}

try {
    // Vérification si le compte est bloqué
    $stmt = $pdo->prepare("SELECT compte_bloque FROM pharmacies WHERE email = ?");
    $stmt->execute([$data['email']]);
    $pharmacy = $stmt->fetch();

    if ($pharmacy && $pharmacy['compte_bloque']) {
        echo json_encode(['success' => false, 'message' => 'Ce compte est temporairement bloqué. Veuillez réessayer plus tard.']);
        exit;
    }

    // Récupération des informations de la pharmacie
    $stmt = $pdo->prepare("
        SELECT id, nom, email, password, tentatives_connexion 
        FROM pharmacies 
        WHERE email = ?
    ");
    $stmt->execute([$data['email']]);
    $pharmacy = $stmt->fetch();

    if (!$pharmacy) {
        echo json_encode(['success' => false, 'message' => 'Email ou mot de passe incorrect']);
        exit;
    }

    // Vérification du mot de passe
    if (!password_verify($data['password'], $pharmacy['password'])) {
        // Incrémentation des tentatives de connexion
        $stmt = $pdo->prepare("
            UPDATE pharmacies 
            SET tentatives_connexion = tentatives_connexion + 1,
                compte_bloque = CASE 
                    WHEN tentatives_connexion + 1 >= 3 THEN 1 
                    ELSE compte_bloque 
                END
            WHERE id = ?
        ");
        $stmt->execute([$pharmacy['id']]);

        $remaining_attempts = 3 - ($pharmacy['tentatives_connexion'] + 1);
        $message = $remaining_attempts > 0 
            ? "Email ou mot de passe incorrect. Il vous reste $remaining_attempts tentative(s)"
            : "Compte bloqué après 3 tentatives échouées. Veuillez réessayer plus tard.";

        echo json_encode(['success' => false, 'message' => $message]);
        exit;
    }

    // Réinitialisation des tentatives de connexion
    $stmt = $pdo->prepare("
        UPDATE pharmacies 
        SET tentatives_connexion = 0,
            compte_bloque = 0
        WHERE id = ?
    ");
    $stmt->execute([$pharmacy['id']]);

    // Création de la session
    session_start();
    $_SESSION['pharmacy_id'] = $pharmacy['id'];
    $_SESSION['pharmacy_name'] = $pharmacy['nom'];

    echo json_encode([
        'success' => true,
        'message' => 'Connexion réussie',
        'pharmacy' => [
            'id' => $pharmacy['id'],
            'nom' => $pharmacy['nom'],
            'email' => $pharmacy['email']
        ]
    ]);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erreur lors de la connexion: ' . $e->getMessage()
    ]);
}
?> 