<?php
require_once 'config.php';
require_once 'functions.php';

// Activer l'affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Test d'enregistrement d'un utilisateur</h1>";

// Données de test
$testData = [
    'nom' => 'Test',
    'prenom' => 'User',
    'region' => 'Tunis',
    'latitude' => '36.8065',
    'longitude' => '10.1815'
];

echo "<h2>Données de test:</h2>";
echo "<pre>";
print_r($testData);
echo "</pre>";

// Nettoyer les données
$nom = clean_input($testData['nom']);
$prenom = clean_input($testData['prenom']);
$region = clean_input($testData['region']);
$latitude = clean_input($testData['latitude']);
$longitude = clean_input($testData['longitude']);

echo "<h2>Données nettoyées:</h2>";
echo "<p>Nom: $nom</p>";
echo "<p>Prénom: $prenom</p>";
echo "<p>Région: $region</p>";
echo "<p>Latitude: $latitude</p>";
echo "<p>Longitude: $longitude</p>";

// Obtenir l'ID de la région
$regionId = getRegionId($region);
echo "<h2>ID de la région:</h2>";
if ($regionId) {
    echo "<p>ID de la région '$region': $regionId</p>";
} else {
    echo "<p>Région '$region' non trouvée dans la base de données.</p>";
    
    // Afficher toutes les régions disponibles
    echo "<h3>Régions disponibles:</h3>";
    $sql = "SELECT id, nom FROM regions ORDER BY nom";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "<ul>";
        while($row = $result->fetch_assoc()) {
            echo "<li>ID: " . $row['id'] . ", Nom: " . $row['nom'] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Aucune région trouvée dans la base de données.</p>";
    }
}

// Préparer la requête SQL
$date_creation = date('Y-m-d H:i:s');
$sql = "INSERT INTO utilisateurs (nom, prenom, region_id, latitude, longitude, date_creation) VALUES ('$nom', '$prenom', $regionId, '$latitude', '$longitude', '$date_creation')";

echo "<h2>Requête SQL:</h2>";
echo "<pre>$sql</pre>";

// Exécuter la requête SQL
if ($regionId) {
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>Enregistrement réussi!</p>";
        echo "<p>ID de l'utilisateur: " . $conn->insert_id . "</p>";
    } else {
        echo "<p style='color: red;'>Erreur lors de l'enregistrement: " . $conn->error . "</p>";
    }
} else {
    echo "<p style='color: red;'>Impossible d'enregistrer l'utilisateur car la région n'existe pas.</p>";
}

// Afficher les utilisateurs enregistrés
$sql = "SELECT * FROM utilisateurs ORDER BY id DESC LIMIT 5";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Derniers utilisateurs enregistrés:</h2>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Nom</th><th>Prénom</th><th>Région ID</th><th>Latitude</th><th>Longitude</th><th>Date de création</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['nom'] . "</td>";
        echo "<td>" . $row['prenom'] . "</td>";
        echo "<td>" . $row['region_id'] . "</td>";
        echo "<td>" . $row['latitude'] . "</td>";
        echo "<td>" . $row['longitude'] . "</td>";
        echo "<td>" . $row['date_creation'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Aucun utilisateur trouvé dans la base de données.</p>";
}
?> 