<?php
require_once 'config.php';
require_once 'functions.php';

// Vérifier si l'utilisateur est connecté
session_start();
if (!isset($_SESSION['pharmacy_id'])) {
    echo json_encode(['error' => 'Non autorisé. Veuillez vous connecter.']);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['nom'])) {
    echo json_encode(['error' => 'Données manquantes']);
    exit;
}

$nom = clean_input($data['nom']);

if (empty($nom)) {
    echo json_encode(['error' => 'Nom de médicament invalide']);
    exit;
}

try {
    if (removeMedicamentFromStock($_SESSION['pharmacy_id'], $nom)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Erreur lors de la suppression du médicament']);
    }
} catch (Exception $e) {
    error_log("Erreur dans remove_medicament.php : " . $e->getMessage());
    echo json_encode(['error' => 'Une erreur est survenue lors de la suppression du médicament']);
}
?>