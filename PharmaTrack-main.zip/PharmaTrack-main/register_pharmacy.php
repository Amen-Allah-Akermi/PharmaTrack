<?php
header('Content-Type: application/json');
require_once 'config.php';

// Activation des logs d'erreur
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Vérification de la méthode de requête
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

// Récupération des données du formulaire
$rawData = file_get_contents('php://input');
$data = json_decode($rawData, true);

// Log des données reçues
error_log("Données reçues : " . print_r($data, true));

// Vérification des champs requis
if (empty($data['nom']) || empty($data['email']) || empty($data['password']) || 
    empty($data['telephone']) || empty($data['region_id']) || 
    empty($data['latitude']) || empty($data['longitude']) || empty($data['jour_repos']) ||
    empty($data['heure_ouverture']) || empty($data['heure_fermeture']) || empty($data['type_pharmacie'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Tous les champs sont requis',
        'received_data' => $data
    ]);
    exit;
}

try {
    // Vérification si l'email existe déjà
    $stmt = $pdo->prepare("SELECT id FROM pharmacies WHERE email = ?");
    $stmt->execute([$data['email']]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Cet email est déjà utilisé']);
        exit;
    }

    // Vérification si le téléphone existe déjà
    $stmt = $pdo->prepare("SELECT id FROM pharmacies WHERE telephone = ?");
    $stmt->execute([$data['telephone']]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Ce numéro de téléphone est déjà utilisé']);
        exit;
    }

    // Hashage du mot de passe
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);

    // Insertion de la pharmacie
    $stmt = $pdo->prepare("
        INSERT INTO pharmacies (nom, email, mot_de_passe, telephone, region_id, latitude, longitude, jour_repos, heure_ouverture, heure_fermeture, type_pharmacie)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $result = $stmt->execute([
        $data['nom'],
        $data['email'],
        $hashedPassword,
        $data['telephone'],
        $data['region_id'],
        $data['latitude'],
        $data['longitude'],
        $data['jour_repos'],
        $data['heure_ouverture'],
        $data['heure_fermeture'],
        $data['type_pharmacie']
    ]);

    if (!$result) {
        error_log("Erreur lors de l'insertion : " . print_r($stmt->errorInfo(), true));
        echo json_encode([
            'success' => false,
            'message' => 'Erreur lors de l\'enregistrement dans la base de données'
        ]);
        exit;
    }

    $pharmacyId = $pdo->lastInsertId();

    echo json_encode([
        'success' => true,
        'message' => 'Pharmacie enregistrée avec succès',
        'pharmacy_id' => $pharmacyId
    ]);

} catch (PDOException $e) {
    error_log("Exception PDO : " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erreur lors de l\'enregistrement: ' . $e->getMessage()
    ]);
}
?> 