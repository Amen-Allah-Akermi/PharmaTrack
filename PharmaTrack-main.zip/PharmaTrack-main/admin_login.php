<?php
header('Content-Type: application/json');
require_once 'config.php';

// Vérification de la méthode de requête
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

// Récupération des données du formulaire
$data = json_decode(file_get_contents('php://input'), true);

// Vérification des champs requis
if (empty($data['email']) || empty($data['password'])) {
    echo json_encode(['success' => false, 'message' => 'Email et mot de passe requis']);
    exit;
}

try {
    // Vérification des identifiants de la pharmacie
    $stmt = $pdo->prepare("SELECT id, email, mot_de_passe FROM pharmacies WHERE email = ?");
    $stmt->execute([$data['email']]);
    $pharmacy = $stmt->fetch();

    if (!$pharmacy) {
        echo json_encode(['success' => false, 'message' => 'Email ou mot de passe incorrect']);
        exit;
    }

    // Vérification du mot de passe
    if (!password_verify($data['password'], $pharmacy['mot_de_passe'])) {
        echo json_encode(['success' => false, 'message' => 'Email ou mot de passe incorrect']);
        exit;
    }

    // Création de la session
    session_start();
    $_SESSION['pharmacy_id'] = $pharmacy['id'];
    $_SESSION['pharmacy_email'] = $pharmacy['email'];

    echo json_encode([
        'success' => true,
        'message' => 'Connexion réussie'
    ]);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erreur lors de la connexion: ' . $e->getMessage()
    ]);
}
?> 